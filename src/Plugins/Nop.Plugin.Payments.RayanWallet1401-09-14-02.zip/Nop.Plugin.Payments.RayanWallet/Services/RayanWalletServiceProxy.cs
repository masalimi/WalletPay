﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Requests;
using Nop.Services.Logging;
using Newtonsoft.Json.Serialization;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;
using Nop.Plugin.Payments.RayanWallet.Domain.Services;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Responses;
using Constant = Nop.Plugin.Payments.RayanWallet.Helper.Constant;
using Exception = System.Exception;


namespace Nop.Plugin.Payments.RayanWallet.Services
{
    public class RayanWalletServiceProxy : IRayanWalletServiceProxy
    {
        private readonly ILogger _logger;
        private readonly IHttpClientFactory _clientFactory;

        private readonly IRepository<WalletCustomer> _walletCustomerRepository;
        private readonly IWalletCustomerHistoryService _walletCustomerHistory;
        private readonly RayanWalletPaymentSettings _rayanWalletPaymentSettings;
        public RayanWalletServiceProxy(ILogger logger, IHttpClientFactory clientFactory, RayanWalletPaymentSettings rayanWalletPaymentSettings, IRepository<WalletCustomer> walletCustomerRepository)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            _rayanWalletPaymentSettings = rayanWalletPaymentSettings;
            _walletCustomerRepository = walletCustomerRepository;
        }


        public void ActivateWallet(string baseUrl, Customer customer)
        {
            try
            {
                var walletCustomer = CheckCustomerHasWallet(customer.Id);
                if (walletCustomer != null && string.IsNullOrEmpty(walletCustomer.ReferenceAccountId))
                {
                    var refrenceAccountId = walletCustomer.CustomerId + "_" + customer.Username + "_" + walletCustomer.StoreId;
                    var walletCreateAccount = CreateAccount(baseUrl, new WalletCreateAccountRequest()
                    {
                        referenceAccountId = refrenceAccountId,
                        Status = 1,
                        referenceAccountOwnerId = customer.CustomerGuid.ToString(),
                        referenceAccountOwnerName = customer.Username,
                        maxCreditorBalance = walletCustomer.Amount,
                        maxDebtorBalance = 0,
                        accountTemplateName = Helper.Constant.KR_User,
                        referenceAccountTitle = "حساب برداشتی"
                    });
                    if (walletCreateAccount.Result.Succeeded)
                    {
                        walletCustomer.ReferenceAccountId = refrenceAccountId;
                        _walletCustomerRepository.Update(walletCustomer);
                        var requestDotransaction = new WalletDotransactionRequest()
                        {
                            TransactionType = Helper.Constant.transactionTypeChargeUserWallet,
                            Amount = walletCustomer.Amount,
                            transactionCreditorAccountItems = new List<AccountItems>
                            {
                                new AccountItems() {
                                    amount = walletCustomer.Amount,
                                    referenceAccountId = refrenceAccountId
                                }
                            },
                            referenceNo = (Constant.ChargeWalletHotKey + customer.Id + "_" + Guid.NewGuid() + "_" + customer.RegisteredInStoreId).ToString(),
                            additionalData = customer.Username,
                            localDateTime = DateTime.UtcNow,
                            Category = "OnlineShop",
                            transactionDebtorAccountItems = new List<AccountItems>
                        {
                            new AccountItems(){
                                amount = walletCustomer.Amount,
                                referenceAccountId = Helper.Constant.KalaresanEntrance
                            }
                        }
                        };
                        var walletDoTransaction = WalletDoTransaction(baseUrl, requestDotransaction);
                        if (walletDoTransaction.Result.ResponseCode == "00")
                        {
                            _walletCustomerHistory.InsertWalletCustomerHistory(new WalletCustomerHistory()
                            {
                                CreateDate = DateTime.UtcNow,
                                StoreId = customer.RegisteredInStoreId,
                                WalletCustomerId = walletCustomer.Id
                            });
                            _walletCustomerRepository.Update(new WalletCustomer()
                            {
                                Id = walletCustomer.Id,
                                ReferenceAccountId = refrenceAccountId,
                            });
                        }
                        else
                        {
                            throw new Exception("doTransaction:" + refrenceAccountId);

                        }
                    }
                    else
                    {
                        throw new Exception("createAcount:" + walletCreateAccount);
                    }
                }
                else
                {
                    throw new Exception("کاربری با این مشخصات وجود ندارد ");

                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet ActiveWallet: {baseUrl}+{customer}", ex);
                throw ex;
            }
        }

        public WalletCustomer CheckCustomerHasWallet(int customerId)
        {
            try
            {
                return _walletCustomerRepository.Table.FirstOrDefault(p => p.CustomerId == customerId);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet CheckCustomerHasWallet: {customerId}", ex);
                throw ex;
            }
        }

        public async Task<WalletBalanceResponse> GetBalance(string baseUrl, Customer customer)
        {
            var referenceAccount = GetCustomerWalletRefrenceId(customer);
            try
            {
                var httpClient = _clientFactory.CreateClient("walletBalance");

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                var response = await httpClient.GetAsync($"{baseUrl}/api/v1/Transaction/balance?ReferenceAccountId=" + referenceAccount);
                return JsonConvert.DeserializeObject<WalletBalanceResponse>(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet GetBalance: {baseUrl} - {referenceAccount}", ex);
                throw ex;
            }
        }

        public string GetCustomerWalletRefrenceId(Customer customer)
        {
            try
            {
                return _walletCustomerRepository.Table.FirstOrDefault(p => p.CustomerId == customer.Id)?.ReferenceAccountId;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<WalletCreateAccountResponse> CreateAccount(string baseUrl, WalletCreateAccountRequest request)
        {

            {
                try
                {
                    var x = new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    };
                    var requestString = JsonConvert.SerializeObject(request, x);

                    try
                    {

                        var httpClient = _clientFactory.CreateClient("walletCreateAccount");
                        httpClient.BaseAddress = new Uri(baseUrl);
                        httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                        var response = await httpClient.PostAsync($"{baseUrl}/api/v1/AccountManagement/account/create", new StringContent(requestString, Encoding.UTF8, "application/json"));
                        return JsonConvert.DeserializeObject<WalletCreateAccountResponse>(response.Content.ReadAsStringAsync().Result);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error($"Error on RayanCard TokenAsync: {baseUrl} - {requestString}", ex);
                        throw ex;
                    }
                }

                catch (Exception ex)
                {
                    _logger.Error($"Error on RayanWallet CreateAccount: {baseUrl} - {request}", ex);
                    throw ex;
                }
            }

        }
        public async Task<WalletRequestResponse> WalletRequest(string baseUrl, WalletRequest request)
        {
            var x = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };
            var requestString = JsonConvert.SerializeObject(request, x);
            try
            {
                var httpClient = _clientFactory.CreateClient("walletRequestTransaction");
                httpClient.BaseAddress = new Uri(baseUrl);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                var response = await httpClient.PostAsync($"{baseUrl}/api/v1/Transaction/request", new StringContent(requestString, Encoding.UTF8, "application/json"));
                return JsonConvert.DeserializeObject<WalletRequestResponse>(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet WalletRequest: {baseUrl} - {request}", ex);
                throw ex;
            }
        }

        public async Task<WalletDotransactionResponse> WalletDoTransaction(string baseUrl, WalletDotransactionRequest request)
        {
            var x = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };
            var requestString = JsonConvert.SerializeObject(request, x);

            try
            {
                var httpClient = _clientFactory.CreateClient("dotransaction");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                var response = await httpClient.PostAsync($"{baseUrl}/api/v1/Transaction/dotransaction", new StringContent(requestString, Encoding.UTF8, "application/json"));
                return JsonConvert.DeserializeObject<WalletDotransactionResponse>(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet WalletDoTransaction: {baseUrl} - {request}", ex);
                throw ex;
            }

        }
        public async Task<VerifyResponse> WalletVerify(string baseUrl, VerifyRequest request)
        {
            var x = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };
            var requestString = JsonConvert.SerializeObject(request, x);
            try
            {
                var httpClient = _clientFactory.CreateClient("VerifyTransaction");

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                var response = await httpClient.PostAsync($"{baseUrl}/api/v1/Transaction/verify", new StringContent(requestString, Encoding.UTF8, "application/json"));
                return JsonConvert.DeserializeObject<VerifyResponse>(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet WalletVerify: {baseUrl} - {request}", ex);
                throw ex;
            }

        }
        public async Task<ReverseResponse> WalletReverse(string baseUrl, ReverseRequest request)
        {

            var x = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };
            var requestString = JsonConvert.SerializeObject(request, x);
            try
            {
                var httpClient = _clientFactory.CreateClient("ReverseTransaction");
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _rayanWalletPaymentSettings.RayanWalletPaymentAuthorization);
                var response = await httpClient.PostAsync($"{baseUrl}/api/v1/Transaction/reverse", new StringContent(requestString, Encoding.UTF8, "application/json"));
                return JsonConvert.DeserializeObject<ReverseResponse>(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet WalletReverse: {baseUrl} - {request}", ex);
                throw ex;
            }
        }
        //public async Task<> InsertWalletCustomerHistory(WalletCustomerHistory walletCustomerHistory)
        //{
        //    _walletCustomerHistory.InsertWalletCustomerHistory(new WalletCustomerHistory()
        //    {
        //        CreateDate = DateTime.UtcNow,
        //        StoreId = customer.RegisteredInStoreId,
        //        WalletCustomerId = walletCustomer.Id,
        //        TransactionType = ""
        //    });
        //}
    }
}