﻿using Nop.Core;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.RayanWallet.Services
{
    public partial interface IRayanWalletDataService
    {
		void InsertRayanWalletServiceProxyTransactionRecord(RayanWalletServiceProxyTransactionRecord rayanWalletServiceProxyTransactionRecord);
		void UpdateRayanWalletServiceProxyTransactionRecord(RayanWalletServiceProxyTransactionRecord rayanWalletServiceProxyTransactionRecord);
		IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByOrderId(int orderId);
		IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByRefCode(int refCode);
		IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByAuthority(string authority);

	}
}
