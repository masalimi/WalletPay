﻿using System;
using System.Collections.Generic;
using System.Text;
using Nop.Web.Framework.Models;

namespace Nop.Plugin.Payments.RayanWallet.Models
{
    public class WalletCustomerHistoryListModel : BasePagedListModel<WalletCustomerHistoryModel>
    {
    }
}
