﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.Payments.RayanWallet.Helper
{
    public enum TransactionTypeEnum
    {

    }
}
