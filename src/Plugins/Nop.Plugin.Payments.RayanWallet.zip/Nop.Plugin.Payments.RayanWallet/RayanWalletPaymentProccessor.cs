﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Services.Catalog;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Plugins;
using Nop.Plugin.Payments.RayanWallet.Data;
using Nop.Plugin.Payments.RayanWallet.Domain.Services;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Requests;
using Nop.Plugin.Payments.RayanWallet.Services;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Responses;
using Nop.Services.Common;
using Nop.Services.Customers;
using StackExchange.Profiling.Internal;
using Nop.Plugin.Payments.RayanWallet.Helper;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;

namespace Nop.Plugin.Payments.RayanWallet
{
    public class RayanWalletPaymentProccessor : BasePlugin, IPaymentMethod
    {
        private readonly ILocalizationService _localizationService;
        private readonly IRayanWalletServiceProxy _rayanWalletServicProxy;
        private readonly IWebHelper _webHelper;
        private readonly ICustomerService _customerService;
        private readonly ISettingService _settingService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IRayanWalletDataService _rayanWalletDataService;
        private readonly RayanWalletObjectContext _objectContext;

        private readonly ILogger _logger;
        private readonly RayanWalletPaymentSettings _rayanWalletPaymentSettings;
        private readonly IWorkContext _workContext;
        private readonly IWalletCustomerHistoryService _walletCustomerHistory;


        public RayanWalletPaymentProccessor(ILocalizationService localizationService,
            IRayanWalletServiceProxy rayanWalletServicProxy,
            IWebHelper webHelper,
            ICustomerService customerService,
            ISettingService settingService,
            IOrderProcessingService orderProcessingService,
            IOrderService orderService,
            IRayanWalletDataService rayanWalletDataService,
            RayanWalletObjectContext objectContext,
            ILogger logger,
            RayanWalletPaymentSettings rayanWalletPaymentSettings,
            IWalletCustomerHistoryService walletCustomerHistory,

            IWorkContext workContext)
        {
            _localizationService = localizationService;
            _rayanWalletServicProxy = rayanWalletServicProxy;
            _webHelper = webHelper;
            _customerService = customerService;
            _settingService = settingService;
            _orderProcessingService = orderProcessingService;
            _orderService = orderService;
            _rayanWalletDataService = rayanWalletDataService;
            _objectContext = objectContext;
            _logger = logger;
            _rayanWalletPaymentSettings = rayanWalletPaymentSettings;
            _workContext = workContext;
            _walletCustomerHistory = walletCustomerHistory;
        }

        public bool SupportCapture => false;

        public bool SupportPartiallyRefund => false;

        public bool SupportRefund => false;

        public bool SupportVoid => false;

        public RecurringPaymentType RecurringPaymentType => RecurringPaymentType.NotSupported;

        public PaymentMethodType PaymentMethodType => PaymentMethodType.Redirection;

        public bool SkipPaymentInfo => true;

        public string PaymentMethodDescription
        {
            get
            {
                var currentcustomer = _workContext.CurrentCustomer;
                var walletBalance = _rayanWalletServicProxy.GetBalance(_rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl, currentcustomer);
                if (walletBalance.Result.ResponseCode == "00")
                    return _localizationService.GetResource("Plugins.Payments.Wallet.PaymentBalanceDescription") + walletBalance.Result.Balance;
                else
                    return "0";
            }
        }


        public CancelRecurringPaymentResult CancelRecurringPayment(CancelRecurringPaymentRequest cancelPaymentRequest)
        {
            return new CancelRecurringPaymentResult { Errors = new[] { "Cancel Recurring not supported" } };
        }

        public bool CanRePostProcessPayment(Order order)
        {
            return true;
        }

        public CapturePaymentResult Capture(CapturePaymentRequest capturePaymentRequest)
        {
            return new CapturePaymentResult { Errors = new[] { "Capture not supported" } };
        }

        public decimal GetAdditionalHandlingFee(IList<ShoppingCartItem> cart)
        {
            return decimal.Zero;
        }

        public ProcessPaymentRequest GetPaymentInfo(IFormCollection form)
        {
            return new ProcessPaymentRequest();
        }

        public void GetPublicViewComponent(out string viewComponentName)
        {
            //TODO: by setting
            //viewComponentName = "PaymentRayanWallet";
            throw new NotImplementedException();
        }

        public bool HidePaymentMethod(IList<ShoppingCartItem> cart)
        {
            var currentcustomer = _workContext.CurrentCustomer;
            var customerWallet = _rayanWalletServicProxy.CheckCustomerHasWallet(currentcustomer.Id);
            return (customerWallet != null && string.IsNullOrEmpty(customerWallet.ReferenceAccountId));
        }

        public void PostProcessPayment(PostProcessPaymentRequest postProcessPaymentRequest)
        {
            //var baseUrl = _rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl;
            //var gatewayUrl = _rayanWalletPaymentSettings.RayanWalletPaymentGatewayUrl;
            ////var acceptorIp = _rayanWalletPaymentSettings.RayanWalletPaymentAcceptorIp;
            //var mechantId = _rayanWalletPaymentSettings.RayanWalletPaymentMerchantId;
            //var useToman = _rayanWalletPaymentSettings.RayanWalletPaymentUseToman;

            //var storeLocation = _webHelper.GetStoreLocation();

            //try
            //{

            //    var pendingOrderId = _rayanWalletDataService.GetServiceTransactionsByOrderId(postProcessPaymentRequest.Order.Id);
            //    if (pendingOrderId.Count() > 0)
            //        return;

            //    var refCode = _rayanWalletPaymentSettings.RayanWalletPaymentRefCode;
            //    _rayanWalletPaymentSettings.RayanWalletPaymentRefCode++;
            //    _settingService.SaveSetting(_rayanWalletPaymentSettings, postProcessPaymentRequest.Order.StoreId);

            //    var request = new Domain.Services.Requests.PaymentRequest()
            //    {
            //        Amount = useToman ? (int)Math.Ceiling(postProcessPaymentRequest.Order.OrderTotal * 10) : (int)Math.Ceiling(postProcessPaymentRequest.Order.OrderTotal),
            //        CallbackURL = $"{storeLocation}Plugins/PaymentRayanWallet/CallBack",
            //        Mobile = "",// postProcessPaymentRequest.Order.Customer.Username,
            //        Email = postProcessPaymentRequest.Order.Customer.Email,
            //        Description = "",
            //        MerchantID = mechantId,
            //    };

            //    #region Insert Service Transaction

            //    var rayanWalletServiceProxyTransactionRecord = new Domain.Data.RayanWalletServiceProxyTransactionRecord
            //    {
            //        OrderId = postProcessPaymentRequest.Order.Id,
            //        RefCode = refCode,
            //        State = RayanWalletServiceProxyStateEnum.Request,
            //        RequestJson = JsonConvert.SerializeObject(request, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
            //        RequestDateUtc = DateTime.UtcNow,
            //    };

            //    _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanWalletServiceProxyTransactionRecord);

            //    #endregion

            //    //Request Token
            //    var response = _rayanWalletServicProxy.PaymentRequestAsync(baseUrl, request).Result;

            //    var responseString = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();

            //    //var t = httpResponse.Content.ReadAsStringAsync().Result;
            //    // JsonSerializer.Deserialize<PaymentResponse>(httpResponse.Content.ReadAsStringAsync().Result, jsonOptions);

            //    #region Updeate Service Transaction

            //    rayanWalletServiceProxyTransactionRecord.ResponseJson = responseString;
            //    rayanWalletServiceProxyTransactionRecord.ResponseDateUtc = DateTime.UtcNow;
            //    _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanWalletServiceProxyTransactionRecord);

            //    #endregion

            //    //Save Request result in order record
            //    //(Optional)
            //    postProcessPaymentRequest.Order.AuthorizationTransactionResult = response.StatusCode.ToString();
            //    _orderService.UpdateOrder(postProcessPaymentRequest.Order);

            //    if (response.IsSuccessStatusCode && JsonConvert.DeserializeObject<PaymentResponse>(response.Content.ReadAsStringAsync().Result).Status == 100)
            //    {
            //        //merchant_token
            //        var authority = JsonConvert.DeserializeObject<PaymentResponse>(responseString).Authority;
            //        //Save Token in order record
            //        //(Optional)
            //        postProcessPaymentRequest.Order.AuthorizationTransactionId = authority;
            //        _orderService.UpdateOrder(postProcessPaymentRequest.Order);

            //        _httpContextAccessor.HttpContext.Response.Redirect($"{gatewayUrl}{authority}");
            //    }
            //    else //if request token is not ok
            //    {
            //        _logger.Warning(message: $"RequestPaymentTokenAsync is not success", customer: postProcessPaymentRequest.Order.Customer);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error("Error on PostProcessPayment", ex, postProcessPaymentRequest.Order.Customer);
            //}

        }

        public ProcessPaymentResult ProcessPayment(ProcessPaymentRequest processPaymentRequest)
        {
            var customer = _customerService.GetCustomerById(processPaymentRequest.CustomerId);
            var walletCustomer = _rayanWalletServicProxy.CheckCustomerHasWallet(customer.Id);
            var useToman = _rayanWalletPaymentSettings.RayanWalletPaymentUseToman;
            var baseUrl = _rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl;

            var orderAmount = _rayanWalletServicProxy.GetBalance(baseUrl, customer);

            var amount = useToman
                ? (int)Math.Ceiling(processPaymentRequest.OrderTotal * 10)
                : (int)Math.Ceiling(processPaymentRequest.OrderTotal);
            var responsePaymentResult = new ProcessPaymentResult();

            var refCode = _rayanWalletPaymentSettings.RayanWalletPaymentRefCode;
            _rayanWalletPaymentSettings.RayanWalletPaymentRefCode++;
            _settingService.SaveSetting(_rayanWalletPaymentSettings, processPaymentRequest.StoreId);

            if (amount <= orderAmount.Result.Balance)
            {
                var request = new WalletRequest()
                {
                    Amount = amount,
                    referenceNo = (Constant.StorePaymentHotKey + customer.Id + "_" + Guid.NewGuid() + "_" + customer.RegisteredInStoreId).ToString(),
                    additionalData = processPaymentRequest.OrderGuid.ToString(),
                    localDateTime = DateTime.UtcNow,
                    transactionCreditorAccountItems =
                        new List<AccountItems>()
                        {
                             new AccountItems()
                        {
                            amount = amount,
                            referenceAccountId = Helper.Constant.KalaResanSettlement
                        }
                        },
                    Category = "OnlineShop",
                    transactionType = Helper.Constant.transactionTypeStorePayment,
                    transactionDebtorAccountItems = new List<AccountItems>()
                    {
                        new AccountItems()
                            {
                                amount = amount,
                                referenceAccountId =walletCustomer.ReferenceAccountId
                            }
                    }

                };

                var rayanwalletServiceProxyTransactionRecord = new Domain.Data.RayanWalletServiceProxyTransactionRecord()
                {
                    OrderId = processPaymentRequest.InitialOrderId,
                    RefCode = refCode,
                    State = RayanWalletServiceProxyStateEnum.request,
                    RequestJson = JsonConvert.SerializeObject(request, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
                    RequestDateUtc = DateTime.UtcNow,
                };
                _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecord);

                var requestServiceResponse = _rayanWalletServicProxy.WalletRequest(baseUrl, request);
                if (requestServiceResponse.Result.ResponseCode == "00")
                {
                    #region InsertHistoryUser
                    _walletCustomerHistory.InsertWalletCustomerHistory(new WalletCustomerHistory()
                    {
                        CreateDate = DateTime.UtcNow,
                        StoreId = customer.RegisteredInStoreId,
                        WalletCustomerId = walletCustomer.Id,
                        TransactionType = " درخواست کسر از حساب ولت کاربر",
                        OrderId = processPaymentRequest.OrderGuid
                    });
                    #endregion
                    responsePaymentResult.NewPaymentStatus = PaymentStatus.Pending;

                    var responseString = requestServiceResponse.Result;

                    rayanwalletServiceProxyTransactionRecord.ResponseJson = responseString.ToJson();
                    rayanwalletServiceProxyTransactionRecord.ResponseDateUtc = DateTime.UtcNow;
                    _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecord);
                    if (ShowVerifyPopUpSms(customer.Username = "09199168566"))
                    {
                        var walleteVerifyRequest = new VerifyRequest()
                        {
                            localDateTime = requestServiceResponse.Result.localDateTime,
                            Amount = amount,
                            referenceNo = requestServiceResponse.Result.referenceNo
                        };

                        #region insertVerifyRecord
                        var rayanwalletServiceProxyTransactionRecordVerifyRequest = new Domain.Data.RayanWalletServiceProxyTransactionRecord()
                        {
                            OrderId = processPaymentRequest.InitialOrderId,
                            RefCode = refCode,
                            State = RayanWalletServiceProxyStateEnum.verify,
                            RequestJson = JsonConvert.SerializeObject(walleteVerifyRequest, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
                            RequestDateUtc = DateTime.UtcNow,
                        };
                        _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordVerifyRequest);

                        #endregion
                        var verify = _rayanWalletServicProxy.WalletVerify(baseUrl, walleteVerifyRequest);
                        if (verify.Result.ResponseCode == "00")
                        {

                            #region InsertHistoryUser
                            _walletCustomerHistory.InsertWalletCustomerHistory(new WalletCustomerHistory()
                            {
                                CreateDate = DateTime.UtcNow,
                                StoreId = customer.RegisteredInStoreId,
                                WalletCustomerId = walletCustomer.Id,
                                TransactionType = " تایید درخواست کسر از حساب ولت کاربر",
                                OrderId = processPaymentRequest.OrderGuid
                            });
                            #endregion
                            responsePaymentResult.NewPaymentStatus = PaymentStatus.Paid;
                        }
                        else
                        {
                            verify.Result.errors.ForEach(p => responsePaymentResult.AddError(p.errorDescription));
                        }
                        #region updateVerifyRecord
                        rayanwalletServiceProxyTransactionRecordVerifyRequest.ResponseJson = verify.Result.ToJson();
                        rayanwalletServiceProxyTransactionRecordVerifyRequest.ResponseDateUtc = DateTime.UtcNow;
                        _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordVerifyRequest);
                        #endregion
                    }
                    else
                    {
                        var reverse = _rayanWalletServicProxy.WalletReverse(baseUrl, new ReverseRequest()
                        {
                            referenceNo = requestServiceResponse.Result.referenceNo,
                            localDateTime = requestServiceResponse.Result.localDateTime,
                            Amount = amount
                        });

                        #region InsertHistoryUser
                        _walletCustomerHistory.InsertWalletCustomerHistory(new WalletCustomerHistory()
                        {
                            CreateDate = DateTime.UtcNow,
                            StoreId = customer.RegisteredInStoreId,
                            WalletCustomerId = walletCustomer.Id,
                            TransactionType = " بازگشت درخواست کسر از حساب ولت کاربر",
                            OrderId = processPaymentRequest.OrderGuid
                        });
                        #endregion
                        #region insertWalletReverse
                        var rayanwalletServiceProxyTransactionRecordVerifyReverse = new Domain.Data.RayanWalletServiceProxyTransactionRecord()
                        {
                            OrderId = processPaymentRequest.InitialOrderId,
                            RefCode = refCode,
                            State = RayanWalletServiceProxyStateEnum.reverse,
                            RequestJson = JsonConvert.SerializeObject(reverse, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
                            RequestDateUtc = DateTime.UtcNow,
                        };
                        _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordVerifyReverse);
                        #endregion
                        if (reverse.Result.ResponseCode == "00")
                        {
                            responsePaymentResult.NewPaymentStatus = PaymentStatus.Voided;
                        }
                        else
                        {
                            reverse.Result.errors.ForEach(p => responsePaymentResult.AddError(p.errorDescription));
                        }
                        #region updateReverse
                        rayanwalletServiceProxyTransactionRecordVerifyReverse.ResponseJson = reverse.Result.ToJson();
                        rayanwalletServiceProxyTransactionRecordVerifyReverse.ResponseDateUtc = DateTime.UtcNow;
                        _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordVerifyReverse);
                        #endregion

                    }
                }
                    return responsePaymentResult;
            }
            else
            {
                var result = new ProcessPaymentResult();
                result.AddError("موجودی کیف پول شما کافی نمی باشد");
                result.NewPaymentStatus = PaymentStatus.Voided;
                return result;
            };
        }

            private bool ShowVerifyPopUpSms(string customerUsername)
            {
                var random = new Random();
                int result = random.Next(1000, 10000);
                return true;
            }

            public ProcessPaymentResult ProcessRecurringPayment(ProcessPaymentRequest processPaymentRequest)
            {
                return new ProcessPaymentResult { Errors = new[] { "Process Recurring not supported" } };
            }

            public RefundPaymentResult Refund(RefundPaymentRequest refundPaymentRequest)
            {
                return new RefundPaymentResult { Errors = new[] { "Refund Payment not supported" } };
            }

            public IList<string> ValidatePaymentForm(IFormCollection form)
            {
                return new List<string>();
            }

            public VoidPaymentResult Void(VoidPaymentRequest voidPaymentRequest)
            {
                return new VoidPaymentResult { Errors = new[] { "Void not supported" } };
            }

        public override void Install()
        {
            var settings = new RayanWalletPaymentSettings
            {
                RayanWalletPaymentBaseUrl = "http://ewallet-serviceapi-gateway.staging.rayanpay.local",// "https://pms.rayanpay.com/",
                RayanWalletPaymentAuthorization = "Bearer " +
                "eyJhbGciOiJSUzUxMiIsInR5cCI6ImF0K2p3dCJ9.eyJuYmYiOjE2Njc5ODU0NDcsImV4cCI6MTk4MzYwNDU2NywiaXNzIjoiaHR0cDovL2V3YWxsZXQtd2ViYXBpLWdhdGV3YXkuc3RhZ2luZy5yYXlhbnBheS5sb2NhbCIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWUiOiJUb2tlbjIwMjItMTEtMDkiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjIxM2YxNjZlLWVmZGEtNGY3OS05Zjg3LWIzZDIwOTY4YmY3YiIsInRlbmFudElkIjoiODU0NDRjODItNTU0MS00N2MxLWJjNGEtOGM1NDY0Yjk4MTBhIiwidGVuYW50X25hbWUiOiJLYWxhUmVzYW4iLCJ2YWxpZF9pcHMiOiIiLCJ0b2tlbl90eXBlIjoiU2VydmljZVRva2VuIiwid19zcCI6WyJBY2NvdW50UmVnaXN0cmF0aW9ufHtcInBuXCI6XCJBY2NvdW50UmVnaXN0cmF0aW9uXCIsXCJydlwiOm51bGx9IiwiRG9UcmFuc2FjdGlvbnx7XCJwblwiOlwiRG9UcmFuc2FjdGlvblwiLFwicnZcIjpudWxsfSIsIlZlcmlmeVRyYW5zYWN0aW9ufHtcInBuXCI6XCJWZXJpZnlUcmFuc2FjdGlvblwiLFwicnZcIjpudWxsfSIsIlJldmVyc2VUcmFuc2FjdGlvbnx7XCJwblwiOlwiUmV2ZXJzZVRyYW5zYWN0aW9uXCIsXCJydlwiOm51bGx9IiwiR2V0QmFsYW5jZXx7XCJwblwiOlwiR2V0QmFsYW5jZVwiLFwicnZcIjpudWxsfSIsIlJlZnVuZFRyYW5zYWN0aW9ufHtcInBuXCI6XCJSZWZ1bmRUcmFuc2FjdGlvblwiLFwicnZcIjpudWxsfSIsIkVkaXRBY2NvdW50fHtcInBuXCI6XCJFZGl0QWNjb3VudFwiLFwicnZcIjpudWxsfSIsIkFjY291bnRUZW1wbGF0ZVJlZ2lzdHJhdGlvbnx7XCJwblwiOlwiQWNjb3VudFRlbXBsYXRlUmVnaXN0cmF0aW9uXCIsXCJydlwiOm51bGx9IiwiRWRpdEFjY291bnRUZW1wbGF0ZXx7XCJwblwiOlwiRWRpdEFjY291bnRUZW1wbGF0ZVwiLFwicnZcIjpudWxsfSIsIlRyYW5zYWN0aW9uVHlwZVJlZ2lzdHJhdGlvbnx7XCJwblwiOlwiVHJhbnNhY3Rpb25UeXBlUmVnaXN0cmF0aW9uXCIsXCJydlwiOm51bGx9IiwiRWRpdFRyYW5zYWN0aW9uVHlwZXx7XCJwblwiOlwiRWRpdFRyYW5zYWN0aW9uVHlwZVwiLFwicnZcIjpudWxsfSJdfQ.Gx4-NTYEoUwbWywdxeKLm9jFloXOYXZFD7vByrq3YkqP88G98uuyGKa3kZKFO5H5A9sfUXWX3DEEFuU_sXhApfgW_LgVDj70r5T1R1BrSFQWKncEgtEU8unJiFAaSbqnDK-xkyAtn78TDZkuUKW8kro-rgv1usLaDCBJcoJhYVTU-XCvdY3406npxMWOF4wV2A1xV5y8TcvzgTp0BDrEGFxPo_cIrUiovFiyIeDjSjGbbNXVLi_xoxMKNFx9pgQ9vdBdvnD-KveoL_jdOCI5OB_96KaohMTAKU0iYfiqPKYL5PNLBDvvWtGYyijcP0yH6o0lLzv5VjxsA9ksOGftIg",
                RayanWalletPaymentRefCode = 0,
                RayanWalletPaymentUseToman = true,
            };

            _settingService.SaveSetting(settings);

            _objectContext.Install();
            // _walletCustomerObjectContext.Install();
            //_walletCustomerHistoryObjectContext.Install();
            _localizationService.AddOrUpdatePluginLocaleResource("Plugins.Payments.RayanWallet.PaymentMethodDescription", "پرداخت از طریق درگاه", "fa-IR");
            base.Install();
        }

        public override void Uninstall()
        {
            _settingService.DeleteSetting<RayanWalletPaymentSettings>();

            _objectContext.Uninstall();
            _localizationService.DeletePluginLocaleResource("Plugins.Payments.RayanWallet.PaymentMethodDescription");
            base.Uninstall();
        }

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/PaymentRayanWallet/Configure";
        }

        public string GetPublicViewComponentName()
        {
            throw new NotImplementedException();
        }
    }
}

