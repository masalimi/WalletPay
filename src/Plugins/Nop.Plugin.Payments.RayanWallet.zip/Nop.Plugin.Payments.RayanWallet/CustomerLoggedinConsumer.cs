﻿using Nop.Core.Domain.Customers;
using Nop.Services.Events;
using Nop.Plugin.Payments.RayanWallet.Services;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Requests;
using Newtonsoft.Json;
using System;
using Nop.Core.Data;
using Nop.Services.Logging;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;
using Nop.Plugin.Payments.RayanWallet.Domain.Services;
using System.Collections.Generic;
using Nop.Plugin.Payments.RayanWallet.Helper;
using StackExchange.Profiling.Internal;
using Newtonsoft.Json.Serialization;

namespace Nop.Plugin.Payments.RayanWallet
{
    public class CustomerLoggedinConsumer : IConsumer<CustomerLoggedinEvent>
    {
        private readonly ILogger _logger;
        private readonly RayanWalletPaymentSettings _rayanWalletPaymentSettings;
        private readonly IRayanWalletServiceProxy _walletServiceProxy;
        private readonly IRayanWalletDataService _rayanWalletDataService;
        private readonly IRepository<WalletCustomer> _walletCustomerRepository;
        private readonly IWalletCustomerHistoryService _walletCustomerHistory;



        public CustomerLoggedinConsumer(ILogger logger, IRayanWalletServiceProxy walletServiceProxy, RayanWalletPaymentSettings rayanWalletPaymentSettings
            , IRayanWalletDataService rayanWalletDataService, IRepository<WalletCustomer> walletCustomerRepository, IWalletCustomerHistoryService walletCustomerHistoryService)
        {
            _logger = logger;
            _walletServiceProxy = walletServiceProxy;
            _rayanWalletPaymentSettings = rayanWalletPaymentSettings;
            _rayanWalletDataService = rayanWalletDataService;
            _walletCustomerRepository = walletCustomerRepository;
            _walletCustomerHistory = walletCustomerHistoryService;
        }
        public void HandleEvent(CustomerLoggedinEvent data)
        {
            try
            {
                var customer = data.Customer;
                var walletCustomer = _walletServiceProxy.CheckCustomerHasWallet(customer.Id);
                if (walletCustomer != null && string.IsNullOrEmpty(walletCustomer.ReferenceAccountId))
                {
                    var refrenceAccountId = walletCustomer.CustomerId + "_" + customer.Username + "_" + walletCustomer.SourceId + "_" + walletCustomer.StoreId;
                    #region InsertCreateAccountLog
                    var createAccountRequest = new WalletCreateAccountRequest()
                    {
                        referenceAccountId = refrenceAccountId,
                        Status = 1,
                        referenceAccountOwnerId = customer.CustomerGuid.ToString(),
                        referenceAccountOwnerName = customer.Username,
                        maxCreditorBalance = walletCustomer.Amount,
                        maxDebtorBalance = 0,
                        accountTemplateName = Helper.Constant.KR_User,
                        referenceAccountTitle = "حساب برداشتی"
                    };
                    var rayanwalletServiceProxyTransactionRecord = new Domain.Data.RayanWalletServiceProxyTransactionRecord()
                    {
                        OrderId = -1,
                        RefCode = -1,
                        State = Domain.Services.RayanWalletServiceProxyStateEnum.createAcount,
                        RequestJson = JsonConvert.SerializeObject(createAccountRequest, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
                        RequestDateUtc = DateTime.UtcNow,
                    };
                    _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecord);
                    #endregion

                    var walletCreateAccount = _walletServiceProxy.CreateAccount(_rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl, createAccountRequest);
                    if (walletCreateAccount.Result.Succeeded)
                    {
                        #region UpdateWalletCreateAcount
                        var responseString = walletCreateAccount.Result;

                        rayanwalletServiceProxyTransactionRecord.ResponseJson = responseString.ToJson();
                        rayanwalletServiceProxyTransactionRecord.ResponseDateUtc = DateTime.UtcNow;
                        _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecord);
                        #endregion

                        #region AddToUserHistory
                        var walletCustomerHistory = new Domain.Data.WalletCustomerHistory()
                        {
                            CreateDate = DateTime.UtcNow,
                            StoreId = customer.RegisteredInStoreId,
                            WalletCustomerId = walletCustomer.Id,
                            TransactionType = " ایجاد حساب ولت کاربر",
                            UpdateDate = DateTime.Now,
                            OrderId = Guid.Empty
                        };
                        _walletCustomerHistory.InsertWalletCustomerHistory(walletCustomerHistory);
                        #endregion


                        var requestDotransaction = new WalletDotransactionRequest()
                        {
                            TransactionType = Helper.Constant.transactionTypeChargeUserWallet,
                            Amount = walletCustomer.Amount,
                            transactionCreditorAccountItems = new List<AccountItems>
                            {
                                new AccountItems() {
                                    amount = walletCustomer.Amount,
                                    referenceAccountId = refrenceAccountId
                                }
                            },
                            referenceNo = (Constant.ChargeWalletHotKey + customer.Id + "_" + Guid.NewGuid() + "_" + customer.RegisteredInStoreId).ToString(),
                            additionalData = customer.Username,
                            localDateTime = DateTime.UtcNow,
                            Category = "OnlineShop",
                            transactionDebtorAccountItems = new List<AccountItems>
                        {
                            new AccountItems(){
                                amount = walletCustomer.Amount,
                                referenceAccountId = Helper.Constant.KalaresanEntrance
                            }
                        }
                        };
                        #region InsertChargeWallet
                        var rayanwalletServiceProxyTransactionRecordChargeWallet = new Domain.Data.RayanWalletServiceProxyTransactionRecord()
                        {
                            OrderId = -1,
                            RefCode = -1,
                            State = Domain.Services.RayanWalletServiceProxyStateEnum.chargeWallet,
                            RequestJson = JsonConvert.SerializeObject(requestDotransaction, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() }),
                            RequestDateUtc = DateTime.UtcNow,
                        };
                        _rayanWalletDataService.InsertRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordChargeWallet);
                        #endregion
                        var walletDoTransaction = _walletServiceProxy.WalletDoTransaction(_rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl, requestDotransaction);
                        if (walletDoTransaction.Result.ResponseCode == "00")
                        {
                            walletCustomer.ReferenceAccountId = refrenceAccountId;
                            _walletCustomerRepository.Update(walletCustomer);
                            #region UpdateWalletCharge
                            var response = walletDoTransaction.Result;

                            rayanwalletServiceProxyTransactionRecordChargeWallet.ResponseJson = responseString.ToJson();
                            rayanwalletServiceProxyTransactionRecordChargeWallet.ResponseDateUtc = DateTime.UtcNow;
                            _rayanWalletDataService.UpdateRayanWalletServiceProxyTransactionRecord(rayanwalletServiceProxyTransactionRecordChargeWallet);
                            #endregion
                            var _walletCustomerHistoryCharge = new Domain.Data.WalletCustomerHistory()
                            {
                                CreateDate = DateTime.UtcNow,
                                StoreId = customer.RegisteredInStoreId,
                                WalletCustomerId = walletCustomer.Id,
                                TransactionType = " شارژ حساب ولت کاربر",
                                OrderId = Guid.Empty
                            };
                            _walletCustomerHistory.InsertWalletCustomerHistory(_walletCustomerHistoryCharge);
                        }
                        else
                        {
                            throw new Exception("doTransaction:" + walletDoTransaction.Result);

                        }
                    }
                    else
                    {
                        throw new Exception("createAcount:" + walletCreateAccount.Result);
                    }
                }
                else
                {
                    throw new Exception("کاربری با این مشخصات وجود ندارد ");

                }
            }
            catch (Exception ex)
            {
                _logger.Error($"Error on RayanWallet ActiveWallet: {data}", ex);
                throw ex;
            }
            //_walletService.ActivateWallet(_rayanWalletPaymentSettings.RayanWalletPaymentBaseUrl, data.Customer);
            //you can access entity using insertEvent.Entity

            //Here goes the business logic you want to perform...

        }
    }
}
