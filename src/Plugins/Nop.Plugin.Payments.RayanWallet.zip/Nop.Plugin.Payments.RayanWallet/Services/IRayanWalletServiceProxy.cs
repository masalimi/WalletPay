﻿using Nop.Core.Domain.Customers;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Requests;
using Nop.Plugin.Payments.RayanWallet.Domain.Services.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;

namespace Nop.Plugin.Payments.RayanWallet.Services
{
    public interface IRayanWalletServiceProxy
    {
        //Task<HttpResponseMessage> PaymentRequestAsync(string requestUrl, PaymentRequest request);
        //Task<HttpResponseMessage> PaymentVerificationAsync(string requestUrl, PaymentVerificationRequest request);

        void ActivateWallet(string baseUrl, Customer customer);
        Task<WalletBalanceResponse> GetBalance(string baseUrl, Customer customer);
        Task<WalletCreateAccountResponse> CreateAccount(string baseUrl, WalletCreateAccountRequest request);
        Task<WalletRequestResponse> WalletRequest(string baseUrl, WalletRequest request);
        Task<WalletDotransactionResponse> WalletDoTransaction(string baseUrl, WalletDotransactionRequest request);
        Task<VerifyResponse> WalletVerify(string baseUrl, VerifyRequest request);
        Task<ReverseResponse> WalletReverse(string baseUrl, ReverseRequest request);
        string GetCustomerWalletRefrenceId(Customer customer);
        WalletCustomer CheckCustomerHasWallet(int customerId);

    }
}
