﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Core.Domain.Customers;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Stores;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;
using Nop.Plugin.Payments.RayanWallet.Helper;
using Nop.Plugin.Payments.RayanWallet.Models;

namespace Nop.Plugin.Payments.RayanWallet.Services
{
    public class WalletCustomerHistoryService : IWalletCustomerHistoryService
    {

        #region Fields

        private readonly IRepository<WalletCustomerHistory> _walletCustomerHistoryRepository;
        private readonly ICacheManager _cacheManager;
        private readonly IRepository<WalletCustomer> _walletCustomerRepository;
        private readonly IRepository<Customer> _customerRepository;
        private readonly IRepository<Order> _orderRepository;
        private readonly IRepository<Store> _storeRepository;
        private readonly IWorkContext _workContext;


        #endregion

        public WalletCustomerHistoryService(IRepository<WalletCustomerHistory> walletCustomerHistoryRepository,
            ICacheManager cacheManager, IRepository<WalletCustomer> walletCustomerRepository, IRepository<Customer> customerRepository, IRepository<Order> orderRepository,
            IRepository<Store> storeRepository, IWorkContext workContext)
        {
            _walletCustomerHistoryRepository = walletCustomerHistoryRepository;
            _cacheManager = cacheManager;
            _walletCustomerRepository = walletCustomerRepository;
            _customerRepository = customerRepository;
            _orderRepository = orderRepository;
            _storeRepository = storeRepository;
            _workContext = workContext;
        }

        public void Log(WalletCustomerHistory record)
        {
            if (record == null)
                throw new ArgumentNullException(nameof(record));
            _walletCustomerHistoryRepository.Insert(record);
        }

        public virtual void InsertWalletCustomerHistory(WalletCustomerHistory walletCustomerHistory)
        {
            if (walletCustomerHistory == null)
                throw new ArgumentNullException(nameof(walletCustomerHistory));

            _walletCustomerHistoryRepository.Insert(walletCustomerHistory);

        }

        public virtual IPagedList<WalletCustomerHistoryModel> GetAll(int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var currentCustomer = _workContext.CurrentCustomer;
            var query = from wus in _walletCustomerHistoryRepository.Table
                        //join ord in _orderRepository.Table on wus.OrderId equals ord.OrderGuid 
                        join wcus in _walletCustomerRepository.Table on wus.WalletCustomerId equals wcus.Id
                        //join cus in _customerRepository.Table on wcus.CustomerId equals cus.Id
                        //join str in _storeRepository.Table on wus.StoreId equals str.Id
                        where wcus.CustomerId == currentCustomer.Id
                        // orderby cus.Username
                        select new WalletCustomerHistoryModel
                        {
                            Amount = wcus.Amount,
                            CreateDate = DateTimeExtentions.ToPersianDateTime(wcus.CreateDate),
                            UpdateDate = DateTimeExtentions.ToPersianDateTime(wcus.UpdateDate),
                           // OrderNo = ord.CustomOrderNumber,
                            TransferTypeWallet = wus.TransactionType,
                        };
            //var s = new IPagedList<WalletCustomerHistoryModel>(WalletCustomerHistoryModel,);
            var records = new PagedList<WalletCustomerHistoryModel>(query, pageIndex, pageSize);
            return records;
        }
        public virtual WalletCustomerHistory GetById(int walletCustomerHistoryId)
        {
            if (walletCustomerHistoryId == 0)
                return null;

            return _walletCustomerHistoryRepository.GetById(walletCustomerHistoryId);
        }
        public virtual void UpdateWalletCustomerHistory(WalletCustomerHistory walletCustomerHistory)
        {
            if (walletCustomerHistory == null)
                throw new ArgumentNullException(nameof(walletCustomerHistory));

            _walletCustomerHistoryRepository.Update(walletCustomerHistory);

            //_cacheManager.RemoveByPrefix(PAYMENTBYWALLET_PATTERN_KEY);
        }
        public virtual void DeleteWalletCustomerHistory(WalletCustomerHistory walletCustomerHistory)
        {
            if (walletCustomerHistory == null)
                throw new ArgumentNullException(nameof(walletCustomerHistory));

            _walletCustomerHistoryRepository.Delete(walletCustomerHistory);

            //_cacheManager.RemoveByPrefix(PAYMENTBYWALLET_PATTERN_KEY);
        }


    }
}
