﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nop.Core;
using Nop.Core.Caching;
using Nop.Core.Data;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;

namespace Nop.Plugin.Payments.RayanWallet.Services
{
    public class RayanWalletDataService : IRayanWalletDataService
    {
        private readonly IRepository<RayanWalletServiceProxyTransactionRecord> _rayanWalletServiceProxyRepository;

        public RayanWalletDataService(IRepository<RayanWalletServiceProxyTransactionRecord> rayanWalletServiceProxyRepository)
        {
            _rayanWalletServiceProxyRepository = rayanWalletServiceProxyRepository;
        }

        public void InsertRayanWalletServiceProxyTransactionRecord(RayanWalletServiceProxyTransactionRecord rayanWalletServiceProxyTransactionRecord)
        {
            if (rayanWalletServiceProxyTransactionRecord == null)
                throw new ArgumentNullException(nameof(rayanWalletServiceProxyTransactionRecord));

            _rayanWalletServiceProxyRepository.Insert(rayanWalletServiceProxyTransactionRecord);
        }

        public void UpdateRayanWalletServiceProxyTransactionRecord(RayanWalletServiceProxyTransactionRecord rayanWalletServiceProxyTransactionRecord)
        {
            if (rayanWalletServiceProxyTransactionRecord == null)
                throw new ArgumentNullException(nameof(rayanWalletServiceProxyTransactionRecord));

            _rayanWalletServiceProxyRepository.Update(rayanWalletServiceProxyTransactionRecord);
        }

        public IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByOrderId(int orderId)
        {
            try
            {
                var transactions = from rayanWalletServiceTranscation in _rayanWalletServiceProxyRepository.Table
                                   where rayanWalletServiceTranscation.OrderId == orderId
                                   select rayanWalletServiceTranscation;
                return transactions;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByRefCode(int refCode)
        {
            var transactions = from rayanWalletServiceTransactions in _rayanWalletServiceProxyRepository.Table
                               where rayanWalletServiceTransactions.RefCode == refCode
                               select rayanWalletServiceTransactions;

            return transactions;
        }
        public IEnumerable<RayanWalletServiceProxyTransactionRecord> GetServiceTransactionsByAuthority(string authority)
        {
            var transactions = from rayanWalletServiceTransactions in _rayanWalletServiceProxyRepository.Table
                               where rayanWalletServiceTransactions.Authority == authority
                               select rayanWalletServiceTransactions;

            return transactions;
        }
    }
}
