﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Nop.Data.Mapping;
using Nop.Plugin.Payments.RayanWallet.Domain.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nop.Plugin.Payments.RayanWallet.Data
{
    public class RayanWalletServiceProxyTransactionRecordMap : NopEntityTypeConfiguration<RayanWalletServiceProxyTransactionRecord>
	{
        public override void Configure(EntityTypeBuilder<RayanWalletServiceProxyTransactionRecord> builder)
        {
            builder.ToTable("RayanWalletServiceTransaction");

            builder.HasKey(x => x.Id);
        }
    }
}
